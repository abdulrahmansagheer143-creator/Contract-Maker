CONTRACT MAKER — ANDROID PROJECT

This project packages the supplied Contract Maker HTML app in an Android WebView.
It keeps the original Arabic contract layout and form, saves contracts locally on
the device, and adds native Android A4 PDF printing.

BUILD APK:
1. Open this folder in Android Studio.
2. Allow Gradle sync and install any requested Android SDK components.
3. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
4. The APK will be at app/build/outputs/apk/debug/app-debug.apk.

BUILD WITHOUT A COMPUTER:
1. Create a GitHub repository and upload all files from this project.
2. Open Actions and run "Build Android APK" (or push to main).
3. Download the "Contract-Maker-APK" artifact from the workflow run.
4. Extract app-debug.apk and install it on your Android phone.

NOTES:
- The app works offline after installation; saved contracts use device-local storage.
- WhatsApp requires WhatsApp to be installed and a valid customer phone number.
- Review and verify customer details, dates, amounts and IBANs before issuing contracts.
- The uploaded HTML contains prefilled example customer details and financial details;
  change them before use.
